#pragma once

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

class MachineControl;

/**
 * @brief Counter operates a periodic counter updates to MachineControl.
 *
 * This class encapsulates a FreeRTOS task that runs a small state machine.
 * It periodically increments a counter value. It can be read out by other 
 * objects, in this case, it's a MachineControl instance.
 */
class Counter
{
public:
    /**
     * @brief Constructs Counter and starts the FreeRTOS task.
     *
     * @param mc Reference to the MachineControl instance that receives counter updates.
     */
    Counter(); // Constructor starts periodic task

    /**
     * @brief Retrieves the current counter value.
     *
     * @param counter Reference to an integer where the current counter value will be stored.
     */
    int getCounterValue();

private:
    TaskHandle_t taskHandle;    ///< FreeRTOS task handle for counter task
    QueueHandle_t counterQueue; ///< Queue for buffering counter values, such that other 
                                ///< tasks can safely read them via getCounterValue();

    /**
     * @brief Main FreeRTOS task execution loop.
     *
     * Runs the counter state machine.
     */
    void runTask();

    /**
     * @brief Static wrapper to connect FreeRTOS task entry to C++ instance method.
     *
     * @param arg Pointer to Counter instance.
     */
    static void taskWrapper(void *arg); // FreeRTOS task wrapper
};
